# Porter Auto Helper v0.9 — detection diagnostics build

## Purpose
Improve visibility into Android Accessibility events and offer candidates before relying on any automatic action.

## v0.9 changes
- Version 0.9 / versionCode 9.
- Adds a local, bounded recent scan history (last 25 diagnostic entries).
- Records exposed window packages, event metadata, unverified-window samples, incomplete Porter signatures, and strong offer matches.
- Suppresses identical diagnostic entries for 1.5 seconds to reduce repetitive logs.
- Forces Auto Accept OFF once on first launch after upgrading to v0.9, preserving the user's ability to turn it on manually later.
- Does not claim that a detected offer or click attempt equals a confirmed Porter booking.

## Test procedure
1. Install v0.9. Confirm Accessibility and notification access remain enabled.
2. Confirm Auto Accept is OFF and Monitoring is ON.
3. While safely parked, test an offer with the screen unlocked, then repeat with the screen locked.
4. After each test, unlock and open Porter Auto Helper. Capture the latest detection and recent scan history.
5. Repeat with another app open if safe. Compare the helper's offer candidate against the actual Porter popup.

## Important limitations
- A screenshot taken after unlocking cannot alone prove the exact moment the Accessibility event was delivered. Use timestamps in the scan history and matching offer details as evidence.
- Android/OEM power management may suspend or delay Accessibility events while locked.
- The current app still uses conservative offer signature matching. Not every Porter screen or overlay is guaranteed to expose readable text.
- Auto Accept is experimental. v0.9 is for detection diagnostics; do not rely on automatic acceptance for real work.
- Test only while parked. This independent app is not affiliated with Porter.

## Existing GitHub Actions workflow
The existing workflow expects the source archive filename `PorterAutoHelper_v0.5_GitHub_Upload.zip`. Upload this archive to the repository root using that exact filename, then run `Build Porter Auto Helper` on `main`.

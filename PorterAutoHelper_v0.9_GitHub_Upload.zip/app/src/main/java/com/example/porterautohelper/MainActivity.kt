package com.example.porterautohelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    companion object {
        const val PREFS = "porter_helper_prefs"
        const val KEY_MIN_AMOUNT = "minimum_amount"
        const val KEY_MONITORING = "monitoring_enabled"
        const val KEY_AUTO_ACCEPT = "auto_accept_enabled"
        const val KEY_LAST_TITLE = "last_title"
        const val KEY_LAST_TEXT = "last_text"
        const val KEY_LAST_STATUS = "last_status"
        const val KEY_LAST_TIME = "last_time"
        const val KEY_LAST_PACKAGE = "last_package"
        const val KEY_LAST_ACTION = "last_action"
        const val KEY_LAST_SCAN = "last_scan_diagnostic"
        const val KEY_SCAN_HISTORY = "scan_history"
        const val KEY_LAST_SCAN_ENTRY = "last_scan_entry"
        const val KEY_LAST_SCAN_ENTRY_TIME = "last_scan_entry_time"
        const val KEY_V09_SAFE_DEFAULT_APPLIED = "v09_safe_default_applied"
        const val KEY_LAST_CLICK_FINGERPRINT = "last_click_fingerprint"
        const val KEY_LAST_CLICK_TIME = "last_click_time"
        val BG = Color.rgb(8, 12, 13)
        val CARD = Color.rgb(19, 27, 28)
        val GREEN = Color.rgb(28, 220, 139)
        val GOLD = Color.rgb(232, 190, 94)
        val MUTED = Color.rgb(151, 169, 166)
        val WHITE = Color.rgb(242, 247, 245)
    }

    private lateinit var root: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pageContent: LinearLayout
    private var page = "HOME"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        // v0.9 starts with Auto Accept OFF even when upgrading from an earlier test build.
        if (!prefs.getBoolean(KEY_V09_SAFE_DEFAULT_APPLIED, false)) {
            prefs.edit().putBoolean(KEY_AUTO_ACCEPT, false)
                .putBoolean(KEY_V09_SAFE_DEFAULT_APPLIED, true).apply()
        }
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        buildShell()
        showPage("HOME")
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 14) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val mark = TextView(this).apply {
            text = "✦"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(GOLD)
            background = rounded(Color.rgb(39, 48, 38), 18f); setPadding(13, 8, 13, 8)
        }
        top.addView(mark)
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0) }
        names.addView(label("PORTER AUTO HELPER", 19f, WHITE, true))
        names.addView(label("SMART PARTNER • VERSION 0.9", 10f, MUTED, true))
        top.addView(names)
        header.addView(top)
        root.addView(header)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        pageContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 4, 18, 22) }
        scroll.addView(pageContent)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(6, 7, 6, 10); setBackgroundColor(Color.rgb(14, 21, 22)) }
        listOf("HOME", "ORDERS", "SETTINGS", "ABOUT").forEach { item ->
            val b = TextView(this).apply {
                text = when (item) { "HOME" -> "⌂\nHOME"; "ORDERS" -> "▤\nORDERS"; "SETTINGS" -> "⚙\nSETTINGS"; else -> "ⓘ\nABOUT" }
                textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (item == page) GREEN else MUTED)
                setPadding(5, 7, 5, 5); setOnClickListener { showPage(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showPage(which: String) {
        page = which
        pageContent.removeAllViews()
        when (which) {
            "HOME" -> homePage()
            "ORDERS" -> ordersPage()
            "SETTINGS" -> settingsPage()
            else -> aboutPage()
        }
    }

    private fun homePage() {
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 22, 18, 22); background = rounded(Color.rgb(15, 42, 32), 24f) }
        hero.addView(label("YOUR NEXT ORDER, SMARTER", 11f, GOLD, true).apply { gravity = Gravity.CENTER })
        hero.addView(label("₹", 38f, GREEN, true).apply { gravity = Gravity.CENTER; setPadding(0, 4, 0, 0) })
        hero.addView(label("OFFER MONITOR", 13f, WHITE, true).apply { gravity = Gravity.CENTER })
        hero.addView(label(if (prefs.getBoolean(KEY_MONITORING, true)) "● MONITORING IS ON" else "○ MONITORING IS PAUSED", 11f, GREEN, true).apply { gravity = Gravity.CENTER; setPadding(0, 8, 0, 0) })
        addCard(hero)

        val monitor = Switch(this).apply {
            text = "Background offer detection"; textSize = 15f; setTextColor(WHITE)
            isChecked = prefs.getBoolean(KEY_MONITORING, true); thumbTintList = tint(GREEN); trackTintList = tint(GREEN)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(KEY_MONITORING, on).apply(); showPage("HOME") }
        }
        val monBox = verticalBox(); monBox.addView(label("LIVE MONITOR", 11f, MUTED, true)); monBox.addView(monitor)
        monBox.addView(label("Looks for offer information exposed by Porter and Android while you use other apps. Detection varies by screen and Android permissions.", 12f, MUTED, false))
        addCard(monBox)

        val amountBox = verticalBox()
        amountBox.addView(label("MINIMUM ORDER VALUE", 11f, GOLD, true))
        val input = EditText(this).apply {
            setSingleLine(true); textSize = 27f; setTextColor(WHITE); setHintTextColor(MUTED); hint = "₹ 100"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getString(KEY_MIN_AMOUNT, "100"))
        }
        amountBox.addView(input)
        amountBox.addView(action("SAVE MINIMUM") {
            val value = input.text.toString().toDoubleOrNull()
            if (value == null || value < 0) toast("Enter a valid amount")
            else { prefs.edit().putString(KEY_MIN_AMOUNT, value.toString()).apply(); toast("Minimum saved: ₹${value}") }
        })
        addCard(amountBox)

        val autoBox = verticalBox()
        autoBox.addView(label("EXPERIMENTAL AUTO ACCEPT", 11f, GOLD, true))
        val auto = Switch(this).apply {
            text = "Automatically accept qualifying offers"; textSize = 14f; setTextColor(WHITE)
            isChecked = prefs.getBoolean(KEY_AUTO_ACCEPT, false)
            thumbTintList = tint(GOLD); trackTintList = tint(GOLD)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean(KEY_AUTO_ACCEPT, on).apply()
                toast(if (on) "Experimental auto accept enabled" else "Auto accept disabled")
            }
        }
        autoBox.addView(auto)
        autoBox.addView(label("OFF by default. v0.9 records diagnostic history for exposed windows and offer candidates. Auto Accept remains experimental; a click attempt is not proof that Porter confirmed the booking. Test while parked.", 12f, MUTED, false))
        addCard(autoBox)

        val live = verticalBox()
        live.addView(label("LATEST DETECTION", 11f, MUTED, true))
        live.addView(label(latestOrder(), 13f, WHITE, false))
        val scan = prefs.getString(KEY_LAST_SCAN, "Waiting for a Porter floating-offer window to be exposed by Android.").orEmpty()
        live.addView(label("SCAN DIAGNOSTIC\n$scan", 11f, MUTED, false))
        addCard(live)

        val access = verticalBox()
        access.addView(label("REQUIRED ACCESS", 11f, MUTED, true))
        access.addView(action("OPEN ACCESSIBILITY SETTINGS") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        access.addView(action("OPEN NOTIFICATION ACCESS") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        addCard(access)
    }

    private fun ordersPage() {
        val box = verticalBox()
        box.addView(label("LATEST OFFER CANDIDATE", 11f, GOLD, true))
        box.addView(label(latestOrder(), 14f, WHITE, false))
        box.addView(label("A detection is only a candidate until you confirm it in Porter Partner. Some screens and overlays may not expose readable information.", 12f, MUTED, false))
        addCard(box)
    }

    private fun settingsPage() {
        val box = verticalBox()
        box.addView(label("PERMISSIONS & CONTROLS", 16f, GREEN, true))
        box.addView(action("ACCESSIBILITY SETTINGS") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        box.addView(action("NOTIFICATION ACCESS") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        box.addView(action("TURN AUTO ACCEPT OFF") { prefs.edit().putBoolean(KEY_AUTO_ACCEPT, false).apply(); toast("Auto accept disabled"); showPage("HOME") })
        box.addView(label("Minimum fare, monitoring and Auto Accept settings are stored on this device.", 12f, MUTED, false))
        addCard(box)
    }

    private fun aboutPage() {
        val box = verticalBox()
        box.addView(label("PORTER AUTO HELPER 0.9", 17f, GREEN, true))
        box.addView(label("An independent companion utility designed to detect short-lived Porter floating offers while you use other apps, compare the fare with your minimum, and optionally attempt acceptance.", 13f, WHITE, false))
        box.addView(label("Auto Accept is experimental and OFF by default. v0.9 adds a local diagnostic history to help inspect Android window and offer detection. Android may not expose every overlay; a click attempt does not guarantee booking. Not affiliated with Porter.", 12f, MUTED, false))
        addCard(box)
    }

    private fun latestOrder(): String {
        val title = prefs.getString(KEY_LAST_TITLE, "Waiting for an offer…").orEmpty()
        val body = prefs.getString(KEY_LAST_TEXT, "").orEmpty()
        val status = prefs.getString(KEY_LAST_STATUS, "No offer candidate detected yet").orEmpty()
        val time = prefs.getLong(KEY_LAST_TIME, 0)
        val action = prefs.getString(KEY_LAST_ACTION, "").orEmpty()
        return buildString {
            append(status)
            if (time > 0) append("\n").append(DateFormat.getTimeInstance().format(Date(time)))
            if (title.isNotBlank()) append("\n").append(title)
            if (action.isNotBlank()) append("\n").append(action)
            if (body.isNotBlank()) append("\n").append(body.take(700))
        }
    }

    private fun addCard(view: View) {
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(17, 15, 17, 15); background = rounded(CARD, 22f, Color.rgb(43, 59, 55)) }
        wrapper.addView(view)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 13
        pageContent.addView(wrapper, lp)
    }

    private fun verticalBox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 4, 0, 7)
    }
    private fun action(text: String, run: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; setTextColor(WHITE); backgroundTintList = tint(Color.rgb(24, 112, 77)); setOnClickListener { run() }
    }
    private fun rounded(color: Int, radius: Float, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; if (stroke != null) setStroke(1, stroke)
    }
    private fun tint(color: Int) = android.content.res.ColorStateList.valueOf(color)
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}

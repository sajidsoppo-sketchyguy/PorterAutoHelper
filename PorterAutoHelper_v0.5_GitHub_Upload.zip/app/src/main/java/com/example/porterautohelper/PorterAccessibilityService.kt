package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Observes exposed offer UI. Experimental acceptance is gated by explicit user opt-in. */
class PorterAccessibilityService : AccessibilityService() {
    private var lastFingerprint = ""
    private var lastSavedAt = 0L
    private var lastClickAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_MONITORING, true)) return
        val acceptedTypes = setOf(
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
        )
        if (event.eventType !in acceptedTypes) return

        val roots = mutableListOf<Pair<String, AccessibilityNodeInfo>>()
        try { event.source?.let { roots.add(it.packageName?.toString().orEmpty() to it) } } catch (_: Exception) { }
        try {
            windows.orEmpty().forEach { window ->
                try { window.root?.let { roots.add(it.packageName?.toString().orEmpty() to it) } } catch (_: Exception) { }
            }
        } catch (_: Exception) { }

        for ((packageName, root) in roots) {
            val text = collectVisibleText(root)
            if (text.isBlank()) continue
            val lower = text.lowercase(Locale.ROOT)
            // Avoid earnings, wallet/ledger, and active/completed trip screens.
            val excluded = listOf("today's earnings", "today’s earnings", "total earnings", "ledger balance", "wallet balance", "completed trip", "trip completed", "end trip", "past orders", "order history")
            if (excluded.any { lower.contains(it) }) continue
            val porterPackage = packageName.contains("porter", ignoreCase = true)
            if (!porterPackage) continue // Do not click controls in unrelated apps.

            // Require an explicit new-offer context; generic trip/distance text is insufficient.
            val offerContext = listOf("new offer", "new trip offer", "offer expires", "incoming offer", "accept this offer", "new order request").any { lower.contains(it) }
            if (!offerContext) continue

            // Prefer an amount explicitly associated with a fare label, not any rupee value.
            val fareMatch = FARE_REGEX.find(text) ?: continue
            val amount = fareMatch.groupValues.getOrNull(1)?.replace(",", "")?.toDoubleOrNull() ?: continue
            val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")?.toDoubleOrNull() ?: 100.0
            val eligible = amount >= minimum
            val fingerprint = "$packageName|${fareMatch.value}|${text.hashCode()}"
            val now = System.currentTimeMillis()
            if (fingerprint == lastFingerprint && now - lastSavedAt < 7000L) continue
            lastFingerprint = fingerprint
            lastSavedAt = now

            prefs.edit()
                .putString(MainActivity.KEY_LAST_TITLE, "Porter offer candidate")
                .putString(MainActivity.KEY_LAST_TEXT, text.take(1200))
                .putString(MainActivity.KEY_LAST_STATUS, if (eligible) "ELIGIBLE • ₹${format(amount)} meets ₹${format(minimum)} minimum" else "BELOW MINIMUM • ₹${format(amount)} is below ₹${format(minimum)}")
                .putString(MainActivity.KEY_LAST_PACKAGE, packageName)
                .putString(MainActivity.KEY_LAST_ACTION, "Not accepted")
                .putLong(MainActivity.KEY_LAST_TIME, now)
                .apply()

            if (eligible && prefs.getBoolean(MainActivity.KEY_AUTO_ACCEPT, false) && now - lastClickAt > 12000L) {
                val acceptNode = findExplicitAcceptControl(root)
                if (acceptNode != null) {
                    val clicked = try { acceptNode.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    if (clicked) {
                        lastClickAt = now
                        prefs.edit().putString(MainActivity.KEY_LAST_ACTION, "Experimental: Accept control click attempted").apply()
                    }
                }
            }
            return
        }
    }

    private fun findExplicitAcceptControl(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        while (queue.isNotEmpty()) {
            val (node, depth) = queue.removeFirst()
            if (depth > 20) continue
            try {
                val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ").trim().lowercase(Locale.ROOT)
                if (node.isClickable && (label == "accept" || label == "accept offer" || label == "accept trip")) return node
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it to depth + 1) }
            } catch (_: Exception) { }
        }
        return null
    }

    private fun collectVisibleText(root: AccessibilityNodeInfo): String {
        val chunks = linkedSetOf<String>()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        while (queue.isNotEmpty() && chunks.size < 400) {
            val (node, depth) = queue.removeFirst()
            if (depth > 22) continue
            try {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it to depth + 1) }
            } catch (_: Exception) { }
        }
        return chunks.joinToString("\n")
    }

    private fun format(value: Double) = String.format(Locale.US, "%.2f", value)
    override fun onInterrupt() {}

    companion object {
        private val FARE_REGEX = Regex("(?:trip\\s*fare|offer\\s*amount|earning\\s*for\\s*this\\s*trip)\\s*[:₹]*\\s*₹?\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    }
}

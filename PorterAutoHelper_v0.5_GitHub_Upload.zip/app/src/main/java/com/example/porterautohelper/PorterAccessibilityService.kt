package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Background offer observer. It inspects accessibility windows exposed by Android,
 * including non-active windows, but never clicks, swipes, or accepts an offer.
 */
class PorterAccessibilityService : AccessibilityService() {
    private var lastFingerprint = ""
    private var lastSavedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_MONITORING, true)) return

        val acceptedTypes = setOf(
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
        )
        if (event.eventType !in acceptedTypes) return

        // Inspect the event source and every interactive/accessibility window Android
        // exposes. This is important when Porter renders an overlay over another app.
        val roots = mutableListOf<Pair<String, AccessibilityNodeInfo>>()
        try {
            event.source?.let { source ->
                val pkg = source.packageName?.toString().orEmpty()
                roots.add(pkg to source)
            }
        } catch (_: Exception) { }
        try {
            windows.orEmpty().forEach { window ->
                try {
                    val root = window.root ?: return@forEach
                    val pkg = root.packageName?.toString().orEmpty()
                    roots.add(pkg to root)
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }

        val seen = HashSet<String>()
        for ((packageName, root) in roots) {
            val text = collectVisibleText(root)
            if (text.isBlank()) continue
            val lower = text.lowercase(Locale.ROOT)
            val amountMatch = AMOUNT_REGEX.find(text) ?: continue

            // Do not assume every window belongs to Porter: some apps render overlays
            // under a different package. Require several offer-specific text signals.
            val signals = listOf("pickup", "drop", "accept", "trip", "delivery", "customer", "distance")
            val signalCount = signals.count { lower.contains(it) }
            val porterPackage = packageName.contains("porter", ignoreCase = true)
            if (signalCount < 2) continue
            if (!porterPackage && signalCount < 3) continue

            val amount = amountMatch.groupValues.getOrNull(1)
                ?.replace(",", "")?.toDoubleOrNull() ?: continue
            val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")
                ?.toDoubleOrNull() ?: 100.0
            val status = if (amount >= minimum) {
                "ELIGIBLE • ₹${format(amount)} meets your ₹${format(minimum)} minimum"
            } else {
                "BELOW MINIMUM • ₹${format(amount)} is below ₹${format(minimum)}"
            }

            val normalizedPackage = packageName.ifBlank { "unknown-window" }
            val fingerprint = "$normalizedPackage|${amountMatch.value}|${text.hashCode()}"
            if (!seen.add(fingerprint)) continue
            val now = System.currentTimeMillis()
            if (fingerprint == lastFingerprint && now - lastSavedAt < 5000L) return
            lastFingerprint = fingerprint
            lastSavedAt = now

            prefs.edit()
                .putString(MainActivity.KEY_LAST_TITLE, "Porter offer candidate")
                .putString(MainActivity.KEY_LAST_TEXT, text.take(1200))
                .putString(MainActivity.KEY_LAST_STATUS, status)
                .putString(MainActivity.KEY_LAST_PACKAGE, normalizedPackage)
                .putLong(MainActivity.KEY_LAST_TIME, now)
                .apply()
            return
        }
    }

    private fun collectVisibleText(root: AccessibilityNodeInfo): String {
        val chunks = linkedSetOf<String>()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        while (queue.isNotEmpty() && chunks.size < 400) {
            val (node, depth) = queue.removeFirst()
            if (depth > 22) continue
            try {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i) ?: continue
                    queue.add(child to depth + 1)
                }
            } catch (_: Exception) { }
        }
        return chunks.joinToString("\n")
    }

    private fun format(value: Double) = String.format(Locale.US, "%.2f", value)

    override fun onInterrupt() {}

    companion object {
        private val AMOUNT_REGEX = Regex("(?:₹|rs\\.?\\s*)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    }
}

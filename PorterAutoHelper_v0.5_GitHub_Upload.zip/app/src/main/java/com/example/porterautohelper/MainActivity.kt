package com.example.porterautohelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    companion object {
        const val PREFS = "porter_helper_prefs"
        const val KEY_MIN_AMOUNT = "minimum_amount"
        const val KEY_MONITORING = "monitoring_enabled"
        const val KEY_LAST_TITLE = "last_title"
        const val KEY_LAST_TEXT = "last_text"
        const val KEY_LAST_STATUS = "last_status"
        const val KEY_LAST_TIME = "last_time"
        const val KEY_LAST_PACKAGE = "last_package"
        val BG = Color.rgb(8, 15, 13); val CARD = Color.rgb(18, 30, 25)
        val GREEN = Color.rgb(35, 220, 139); val MUTED = Color.rgb(157, 178, 167)
    }
    private lateinit var root: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var orderText: TextView
    private lateinit var minInput: EditText
    private lateinit var monitorSwitch: Switch
    private var page = "HOME"

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        window.statusBarColor = BG; window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        buildShell(); showPage("HOME")
    }
    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 12) }
        header.addView(label("PORTER  AUTO HELPER", 22f, GREEN, true))
        header.addView(label("SMART ORDER ASSISTANT  •  2-WHEELER", 10f, MUTED, true).apply { setPadding(0,5,0,0) })
        root.addView(header)
        val content = FrameLayout(this).apply { id = View.generateViewId() }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { setPadding(8,8,8,12); gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(12,22,18)) }
        listOf("HOME", "ORDERS", "SETTINGS", "ABOUT").forEach { name ->
            val b = TextView(this).apply { text = name; textSize = 10f; gravity = Gravity.CENTER; setTextColor(if(name==page) GREEN else MUTED); setPadding(10,12,10,12); setOnClickListener { showPage(name) } }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav); setContentView(root); content.tag = "content"
    }
    private fun showPage(which: String) {
        page = which
        val scroll = (root.getChildAt(1) as ScrollView); val frame = scroll.getChildAt(0) as FrameLayout; frame.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,8,18,24) }
        fun card(view: View) { val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,15,16,15); background=panel() }; box.addView(view); val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=13; col.addView(box,lp) }
        when(which) {
            "HOME" -> {
                card(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL
                    addView(label("MONITORING",12f,MUTED,true)); monitorSwitch = Switch(this@MainActivity).apply { text="Background detection"; textSize=18f; setTextColor(Color.WHITE); isChecked=prefs.getBoolean(KEY_MONITORING,true); buttonTint(GREEN); setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(KEY_MONITORING,on).apply(); refreshStatus() } }; addView(monitorSwitch)
                    addView(label("Detect Porter offer cards while you use other apps when Android exposes their content.",12f,MUTED,false).apply{setPadding(0,8,0,0)}) })
                card(LinearLayout(this).apply { orientation=1; addView(label("MINIMUM ORDER VALUE",11f,MUTED,true)); minInput=EditText(this@MainActivity).apply { setSingleLine(true); textSize=27f; setTextColor(Color.WHITE); setHintTextColor(MUTED); hint="₹ 100"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(prefs.getString(KEY_MIN_AMOUNT,"100")) }; addView(minInput); addView(action("SAVE MINIMUM AMOUNT") { val v=minInput.text.toString().toDoubleOrNull(); if(v==null || v<0) toast("Enter a valid amount") else { prefs.edit().putString(KEY_MIN_AMOUNT,v.toString()).apply(); toast("Minimum saved: ₹${v}") } }) })
                card(LinearLayout(this).apply { orientation=1; addView(label("LIVE STATUS",11f,MUTED,true)); statusText=label("",15f,GREEN,true); addView(statusText); refreshStatus() })
                card(LinearLayout(this).apply { orientation=1; addView(label("LATEST DETECTED OFFER",11f,MUTED,true)); orderText=label("",14f,Color.WHITE,false); addView(orderText); refreshOrder() })
                card(LinearLayout(this).apply { orientation=1; addView(action("NOTIFICATION ACCESS") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }); addView(action("ACCESSIBILITY ACCESS") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) })
            }
            "ORDERS" -> { card(LinearLayout(this).apply { orientation=1; addView(label("LATEST OFFER",12f,MUTED,true)); orderText=label("",15f,Color.WHITE,false); addView(orderText); refreshOrder(); addView(label("Only order-like text with an amount is recorded. Check every offer in Porter before acting.",12f,MUTED,false)) }) }
            "SETTINGS" -> { card(LinearLayout(this).apply { orientation=1; addView(label("DETECTION SETTINGS",16f,GREEN,true)); addView(action("OPEN NOTIFICATION ACCESS") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }); addView(action("OPEN ACCESSIBILITY SETTINGS") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }); addView(label("Minimum amount is editable on Home and saved on this device.",12f,MUTED,false)) }) }
            else -> card(LinearLayout(this).apply { orientation=1; addView(label("ABOUT PORTER AUTO HELPER",16f,GREEN,true)); addView(label("A companion tool for detecting Porter Partner offers and comparing their amount with your chosen minimum.",14f,Color.WHITE,false)); addView(label("Automatic acceptance is not enabled in this build. Detection depends on what Android and Porter expose to accessibility and notifications. Lock-screen detection is not guaranteed.",12f,MUTED,false)) })
        }
        frame.addView(col)
    }
    private fun refreshStatus(){ if(::statusText.isInitialized) statusText.text=if(prefs.getBoolean(KEY_MONITORING,true)) "● MONITORING ENABLED" else "○ MONITORING PAUSED" }
    private fun refreshOrder(){ if(!::orderText.isInitialized)return; val t=prefs.getString(KEY_LAST_TITLE,"").orEmpty(); val body=prefs.getString(KEY_LAST_TEXT,"").orEmpty(); val s=prefs.getString(KEY_LAST_STATUS,"Waiting for a Porter offer…").orEmpty(); val tm=prefs.getLong(KEY_LAST_TIME,0); orderText.text=buildString { append(s); if(tm>0) append("\n").append(DateFormat.getTimeInstance().format(Date(tm))); if(t.isNotBlank())append("\n").append(t); if(body.isNotBlank())append("\n").append(body) } }
    override fun onResume(){super.onResume(); if(::statusText.isInitialized)refreshStatus(); if(::orderText.isInitialized)refreshOrder()}
    private fun label(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold)setTypeface(null,android.graphics.Typeface.BOLD); setPadding(0,4,0,7) }
    private fun action(s:String,run:()->Unit)=Button(this).apply { text=s; textSize=12f; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(24,112,77)); setOnClickListener{run()} }
    private fun panel()=android.graphics.drawable.GradientDrawable().apply { setColor(CARD); cornerRadius=22f; setStroke(1,Color.rgb(34,65,51)) }
    private fun Switch.buttonTint(c:Int){ thumbTintList=android.content.res.ColorStateList.valueOf(c); trackTintList=android.content.res.ColorStateList.valueOf(c) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}

# Porter Auto Helper v0.7 — floating-offer detection test build

## Purpose
This build targets the user's real workflow: the driver is online in Porter Partner while using another app, and a short-lived Porter floating offer may appear for only a few seconds. The helper should not require the driver to keep watching the screen.

## v0.7 changes
- Scans the accessibility event source and all interactive windows exposed by Android.
- Targets a strong floating-offer signature: Porter-owned window, standalone rupee fare, PICKUP, DROP, and an `Accept in Ns` countdown. This excludes ordinary incentive messages that lack route and countdown details.
- Supports the visible countdown label such as `Accept in 7s`, which v0.6 did not recognise as an Accept control.
- Compares the fare against the saved minimum.
- Adds a scan diagnostic on the Home screen to show whether Android exposed a Porter window and which signature elements were visible.
- Adds per-offer duplicate protection and a short click cooldown.
- Auto Accept remains OFF by default. When explicitly enabled, it attempts an accessibility click only after the full signature matches, the fare meets the minimum, and a visible clickable Accept control is found.
- Version name/code: 0.7 / 7.

## Important limitations
- This is an experimental test build, not a guarantee of detection or booking. Android/Porter may expose the floating popup under a different package, omit text nodes, or prevent accessibility interaction. The scan diagnostic is intended to reveal this.
- A successful accessibility click is only an attempted action; always verify that Porter confirms the order.
- Do not use or test the phone while riding. Test while safely parked.
- Auto Accept is OFF by default. Do not enable it until detection is verified with real offers.
- This independent app is not affiliated with Porter.

## Existing GitHub Actions workflow
The workflow currently expects the source archive filename `PorterAutoHelper_v0.5_GitHub_Upload.zip`. Replace that archive's contents with this v0.7 project while keeping that exact filename, then run the existing `Build Porter Auto Helper` workflow on `main`.

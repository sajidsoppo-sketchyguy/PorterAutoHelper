# Porter Auto Helper v0.5

Source update for the existing GitHub Actions APK workflow.

## v0.5 changes
- Keeps the v0.4 dashboard, navigation, master monitoring switch, and saved minimum amount.
- Expands accessibility event coverage to window changes, content changes, scrolling, and notification-state events.
- Inspects the accessibility event source and all interactive/accessibility windows exposed by Android, not only the active foreground window.
- Requires a currency amount and multiple offer-specific text signals. For windows not owned by a package containing `porter`, it applies a stricter text-signal threshold to reduce unrelated-screen matches.
- Compares the detected amount against the user's saved minimum and records eligible/below-minimum status.
- Does not click, swipe, accept, or book orders. Automatic acceptance is intentionally not enabled until real Porter offer controls and permitted interaction behaviour can be verified safely.
- Version name/code updated to 0.5 / 5.

## Build with the existing GitHub workflow
Replace `PorterAutoHelper_v3_Classic_Source.zip` in the repository with this ZIP, commit to `main`, then manually run the existing `Build Porter Auto Helper` workflow. Download the artifact from that specific successful run.

## Important limitations
- This is an improved detection attempt, not a guarantee. Some Porter floating windows may not expose text or may be owned by a package whose name does not contain `porter`.
- Lock-screen detection depends on Android's lock-screen restrictions and whether Porter displays the offer there. It cannot be guaranteed.
- Test while stationary and compare the helper result with the real Porter offer. Do not rely on it while riding.
- No automatic acceptance is implemented.

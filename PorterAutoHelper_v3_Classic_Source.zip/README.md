# Porter Auto Helper v0.3 — Classic theme

This Android starter adds notification-based order detection and a configurable minimum order amount (default ₹100).

## Included
- Configurable minimum amount.
- Notification listener that looks for Porter/order notifications.
- Stores the latest detected notification and labels it eligible, below threshold, or amount unreadable.
- Classic dark-green interface and custom app icon.\n- Shortcut to Android Accessibility Settings.\n- Java and Kotlin JVM targets both set to 17.

## Setup
1. Build the APK.
2. Install it.
3. Open Porter Auto Helper and save the desired minimum (default ₹100).
4. Tap **Enable notification access** and enable access for Porter Auto Helper in Android Settings.
5. Return to the helper and tap **Refresh latest order** after an order notification arrives.

## Limits and safety
- This version does **not** automatically accept or slide orders.
- Android only provides notification text that the Porter app publishes; a generic notification may not contain order details.
- This has not been tested against a live Porter account. Verify accuracy before relying on it.
- Notification access exposes notification content; enable it only if you are comfortable with that.
- Do not use or test this app while riding. Confirm Porter's partner rules before adding any automation.

# Porter Auto Helper v0.4

Updated source project for the existing GitHub Actions APK workflow.

## v0.4 changes
- Redesigned dark emerald dashboard with Home, Orders, Settings and About sections.
- Added a persistent background-monitoring ON/OFF switch.
- Kept the editable, persistent minimum order amount (default ₹100; ₹0 and decimal values are accepted).
- Implemented an accessibility event reader that scans visible accessibility text for an order-like offer containing a currency amount and at least two order terms (pickup/drop/accept/delivery/trip). It records only matching snippets and does not click or accept anything.
- Notification listener respects the master switch and filters for Porter package notifications or notifications with stronger order/amount indicators.
- Updated version name to 0.4 and accessibility configuration to receive relevant window and notification events.

## Build
Use the existing repository and GitHub Actions workflow. Replace the source ZIP in the repository with this ZIP, keeping the filename `PorterAutoHelper_v3_Classic_Source.zip`, then run the existing `Build APK` workflow.

## Important limitations
- This is a first implementation of accessibility-based detection, not proof that every Porter floating card exposes its text. Android/OEM overlays may not expose content to accessibility services.
- Lock-screen visibility/detection depends on Android lock-screen policy and whether Porter displays the offer there; it is not guaranteed.
- Verify the Porter Partner package notification behavior on the device. A package name containing `porter` is accepted; otherwise visible accessibility text must match the offer pattern.
- No automatic acceptance, sliding, clicking, or order booking is implemented.
- Do not rely on this helper while riding. Verify Porter's partner terms and test safely while stationary.

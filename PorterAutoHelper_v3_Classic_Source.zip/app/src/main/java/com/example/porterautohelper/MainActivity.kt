package com.example.porterautohelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    companion object {
        const val PREFS = "porter_helper_prefs"
        const val KEY_MIN_AMOUNT = "minimum_amount"
        const val KEY_LAST_TITLE = "last_title"
        const val KEY_LAST_TEXT = "last_text"
        const val KEY_LAST_STATUS = "last_status"
        const val KEY_LAST_TIME = "last_time"
    }

    private lateinit var minAmount: EditText
    private lateinit var latest: TextView
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val title = TextView(this).apply {
            text = "PORTER  •  AUTO HELPER"
            textSize = 23f
            setTextColor(android.graphics.Color.rgb(25, 183, 122))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        val intro = TextView(this).apply {
            text = "2-wheeler goods orders • Notification helper"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val amountLabel = TextView(this).apply {
            text = "Minimum order amount (₹)"
            textSize = 16f
        }
        minAmount = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(prefs.getString(KEY_MIN_AMOUNT, "100") ?: "100")
            hint = "100"
        }
        val save = Button(this).apply {
            text = "Save minimum amount"
            setOnClickListener {
                val amount = minAmount.text.toString().trim().toDoubleOrNull()
                if (amount == null || amount < 0) {
                    latest.text = "Enter a valid minimum amount."
                } else {
                    prefs.edit().putString(KEY_MIN_AMOUNT, amount.toString()).apply()
                    latest.text = "Minimum saved: ₹${"%.2f".format(amount)}"
                }
            }
        }
        val permission = Button(this).apply {
            text = "Enable notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val accessibility = Button(this).apply {
            text = "Enable screen-reading access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val refresh = Button(this).apply {
            text = "Refresh latest order"
            setOnClickListener { refreshLatest() }
        }
        latest = TextView(this).apply {
            textSize = 15f
            setPadding(12, 12, 12, 12)
            text = ""
        }
        val warning = TextView(this).apply {
            text = "This version reads available notifications and filters by amount. It does not slide or accept orders automatically. Check the order in Porter yourself. Notification access can expose notification content."
            textSize = 13f
            setPadding(12, 12, 12, 12)
        }

        val layout = LinearLayout(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(16, 23, 19))
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 24, 22, 24)
            addView(title, fullWidth())
            addView(intro, fullWidth())
            addView(amountLabel, fullWidthWithTop())
            addView(minAmount, fullWidth())
            addView(save, fullWidth())
            addView(permission, fullWidth())
            addView(accessibility, fullWidth())
            addView(refresh, fullWidth())
            addView(latest, fullWidth())
            addView(warning, fullWidth())
        }
        listOf(intro, amountLabel, latest, warning).forEach {
            it.setTextColor(android.graphics.Color.rgb(232, 238, 233))
        }
        minAmount.setTextColor(android.graphics.Color.WHITE)
        minAmount.setHintTextColor(android.graphics.Color.LTGRAY)
        listOf(save, permission, accessibility, refresh).forEach {
            it.setTextColor(android.graphics.Color.WHITE)
            it.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.rgb(25, 125, 88)))
        }
        setContentView(layout)
        refreshLatest()
    }

    override fun onResume() {
        super.onResume()
        if (::latest.isInitialized) refreshLatest()
    }

    private fun fullWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun fullWidthWithTop(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 18
        }

    private fun refreshLatest() {
        val title = prefs.getString(KEY_LAST_TITLE, "").orEmpty()
        val body = prefs.getString(KEY_LAST_TEXT, "").orEmpty()
        val status = prefs.getString(KEY_LAST_STATUS, "No matching Porter order notification recorded yet.").orEmpty()
        val time = prefs.getLong(KEY_LAST_TIME, 0L)
        val timeText = if (time > 0) DateFormat.getDateTimeInstance().format(Date(time)) else "Not yet"
        latest.text = buildString {
            append("Status: ").append(status).append("\n\n")
            append("Last notification: ").append(timeText).append("\n")
            if (title.isNotBlank()) append("\n").append(title).append("\n")
            if (body.isNotBlank()) append(body)
        }
    }
}

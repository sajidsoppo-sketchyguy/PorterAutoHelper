package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Safe starter: observes accessibility events but does not click or accept orders.
 * Before enabling any automation, verify Porter policy and test on a non-live screen.
 */
class PorterAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally no auto-click logic in this starter version.
        // A future version should be limited to the verified Porter package,
        // have an explicit in-app ON/OFF control, and require safe testing.
    }

    override fun onInterrupt() {}
}

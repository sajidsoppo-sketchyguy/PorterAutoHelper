package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Reads only order-like visible text; never clicks or accepts an order. */
class PorterAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_MONITORING, true)) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        val chunks = mutableListOf<String>()
        fun collect(node: AccessibilityNodeInfo?, depth: Int = 0) {
            if (node == null || depth > 18 || chunks.size > 350) return
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { chunks.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { chunks.add(it) }
            for (i in 0 until node.childCount) collect(node.getChild(i), depth + 1)
        }
        try { collect(rootInActiveWindow) } catch (_: Exception) { }
        val content = chunks.distinct().joinToString("\n")
        if (content.isBlank()) return
        val lower = content.lowercase(Locale.ROOT)
        val hasAmount = Regex("(?:₹|rs\\.?\\s*)\\s*[0-9,]+(?:\\.[0-9]{1,2})?", RegexOption.IGNORE_CASE).containsMatchIn(content)
        val orderTerms = listOf("pickup", "drop", "accept", "delivery", "trip")
        if (!hasAmount || orderTerms.count { lower.contains(it) } < 2) return
        val amount = Regex("(?:₹|rs\\.?\\s*)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE).find(content)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull() ?: return
        val min = prefs.getString(MainActivity.KEY_MIN_AMOUNT,"100")?.toDoubleOrNull() ?: 100.0
        val status = if(amount >= min) "ELIGIBLE • ₹${amount} meets ₹${min}" else "BELOW MINIMUM • ₹${amount} is below ₹${min}"
        prefs.edit().putString(MainActivity.KEY_LAST_TITLE,"Visible offer detected").putString(MainActivity.KEY_LAST_TEXT,content.take(1200)).putString(MainActivity.KEY_LAST_STATUS,status).putString(MainActivity.KEY_LAST_PACKAGE,event.packageName?.toString().orEmpty()).putLong(MainActivity.KEY_LAST_TIME,System.currentTimeMillis()).apply()
    }
    override fun onInterrupt() {}
}

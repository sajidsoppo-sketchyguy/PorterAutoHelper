package com.example.porterautohelper

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.content.SharedPreferences
import android.os.Bundle
import java.util.Locale

class PorterNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val prefs: SharedPreferences = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_MONITORING, true)) return
        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.distinct().joinToString("\n")
        if (combined.isBlank()) return

        val packageName = sbn.packageName.lowercase(Locale.ROOT)
        val content = combined.lowercase(Locale.ROOT)
        // Keep processing narrow: Porter app notifications or notifications clearly mentioning Porter/order details.
        val looksRelevant = packageName.contains("porter") ||
            (content.contains("pickup") && (content.contains("drop") || content.contains("accept")) &&
             (content.contains("₹") || content.contains("rs")))
        if (!looksRelevant) return

        val amount = Regex("(?:₹|rs\\.?\\s*)([0-9,]+(?:\\.\\d{1,2})?)", RegexOption.IGNORE_CASE)
            .find(combined)
            ?.groupValues?.getOrNull(1)
            ?.replace(",", "")
            ?.toDoubleOrNull()

        val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")?.toDoubleOrNull() ?: 100.0
        val status = when {
            amount == null -> "Order notification detected, but amount was not readable."
            amount >= minimum -> "Eligible order detected (₹${"%.2f".format(Locale.US, amount)} ≥ ₹${"%.2f".format(Locale.US, minimum)}). Review it in Porter."
            else -> "Order below minimum (₹${"%.2f".format(Locale.US, amount)} < ₹${"%.2f".format(Locale.US, minimum)}). Filtered out."
        }

        prefs.edit()
            .putString(MainActivity.KEY_LAST_TITLE, title)
            .putString(MainActivity.KEY_LAST_TEXT, combined)
            .putString(MainActivity.KEY_LAST_STATUS, status)
            .putString(MainActivity.KEY_LAST_PACKAGE, packageName)
            .putLong(MainActivity.KEY_LAST_TIME, System.currentTimeMillis())
            .apply()
    }
}

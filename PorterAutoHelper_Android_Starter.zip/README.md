# Porter Auto Helper — starter Android project

This is a free, open-source starter project for Android Studio. It is **not a finished auto-accept app** and does not yet accept or tap orders.

## What's included
- Minimal Android app screen
- Shortcut to Android Accessibility Settings
- Accessibility service skeleton
- Automation is deliberately disabled by default

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build APK(s)**.
5. The debug APK is usually generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This project has not been compiled or tested against the Porter Partner app.
- Accessibility access can expose on-screen content. Enable it only for software you trust.
- Do not share Porter OTPs or passwords with third-party apps.
- Confirm that automation is allowed under Porter's current partner terms before adding any auto-tap behavior.
- Do not use or test the app while riding.

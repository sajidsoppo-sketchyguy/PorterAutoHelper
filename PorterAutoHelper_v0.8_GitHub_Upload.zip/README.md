# Porter Auto Helper v0.8 — window diagnostics build

## Purpose
Observe short-lived Porter delivery offer popups while the driver is using another app. Detection must be verified before relying on automatic acceptance.

## v0.8 changes
- Increments Android version to 0.8 / versionCode 8.
- Keeps the v0.7 strong Porter offer signature and minimum-fare comparison.
- Adds diagnostics for offer-like text exposed by non-Porter windows, including package name, window type/id, event package/class/type, and a short visible-text sample.
- Never attempts an Accept click in a non-Porter or otherwise unverified window.
- Retains the existing user-controlled Auto Accept switch, OFF by default.

## Test procedure
1. Install v0.8 and confirm Accessibility and notification access remain enabled.
2. Keep Auto Accept OFF.
3. While safely parked, go online in Porter Partner and wait for a real offer popup.
4. Open Porter Auto Helper and read the latest scan diagnostic. Record whether the popup is identified as a Porter window or an unverified window, and whether fare, pickup, drop, and countdown are exposed.
5. Repeat with WhatsApp or Instagram open if safe to do so.
6. Share screenshots of the diagnostic and the corresponding offer. Do not share sensitive personal information unnecessarily.

## Safety and limitations
- This is an experimental diagnostic build, not a guarantee of detection, speed, or booking.
- Accessibility event delivery and window exposure depend on Android, the device manufacturer, and Porter.
- A successful accessibility click is only an attempted action; verify Porter confirms the order.
- Do not use or test the phone while riding. Test while safely parked.
- Auto Accept is OFF by default. Keep it OFF until detection is verified.
- This independent app is not affiliated with Porter.

## Existing GitHub Actions workflow
The existing workflow expects the source archive filename `PorterAutoHelper_v0.5_GitHub_Upload.zip`. Keep that exact filename when uploading this v0.8 project to the repository root, then run the existing `Build Porter Auto Helper` workflow on `main`.

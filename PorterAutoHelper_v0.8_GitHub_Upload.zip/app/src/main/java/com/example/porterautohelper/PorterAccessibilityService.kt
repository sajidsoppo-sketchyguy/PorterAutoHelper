package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Experimental observer for the Porter floating offer card.
 * It deliberately requires a strong offer signature before recording or clicking:
 * Porter-owned window + standalone rupee fare + PICKUP + DROP + "Accept in Ns".
 */
class PorterAccessibilityService : AccessibilityService() {
    private var lastFingerprint = ""
    private var lastSavedAt = 0L
    private var lastClickAt = 0L

    private data class WindowRoot(
        val packageName: String,
        val root: AccessibilityNodeInfo,
        val windowType: Int,
        val windowId: Int
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.KEY_MONITORING, true)) return

        val acceptedTypes = setOf(
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
        )
        if (event.eventType !in acceptedTypes) return

        val roots = mutableListOf<WindowRoot>()
        try {
            event.source?.let { source ->
                roots.add(WindowRoot(source.packageName?.toString().orEmpty(), source, -1, -1))
            }
        } catch (_: Exception) { }
        try {
            windows.orEmpty().forEach { window ->
                try {
                    window.root?.let { root ->
                        roots.add(WindowRoot(root.packageName?.toString().orEmpty(), root, window.type, window.id))
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }

        val exposedPackages = roots.map { it.packageName }.filter { it.isNotBlank() }.distinct().take(8)
        if (exposedPackages.isNotEmpty()) {
            prefs.edit().putString(
                MainActivity.KEY_LAST_SCAN,
                "Android exposed windows: ${exposedPackages.joinToString(", ")}; eventPackage=${event.packageName ?: "unknown"}; eventClass=${event.className ?: "unknown"}; eventType=${event.eventType}. Checking visible window text."
            ).apply()
        }

        val seen = mutableSetOf<String>()
        for (entry in roots) {
            val packageName = entry.packageName
            if (packageName.isBlank() || !seen.add("$packageName:${entry.windowId}")) continue
            val text = collectVisibleText(entry.root)
            if (text.isBlank()) continue
            val lower = text.lowercase(Locale.ROOT)

            // Observe every exposed window for diagnosis, but never click controls in an
            // unverified/non-Porter package. This helps identify OEM overlay ownership.
            if (!packageName.contains("porter", ignoreCase = true)) {
                val offerLike = lower.contains("accept") || lower.contains("pickup") ||
                    lower.contains("drop") || text.contains("₹")
                if (offerLike) {
                    val sample = text.replace("\\n", " | ").take(650)
                    prefs.edit().putString(
                        MainActivity.KEY_LAST_SCAN,
                        "UNVERIFIED WINDOW — no click attempted. package=$packageName; " +
                            "windowType=${entry.windowType}; windowId=${entry.windowId}; " +
                            "eventPackage=${event.packageName ?: "unknown"}; " +
                            "eventClass=${event.className ?: "unknown"}; text=$sample"
                    ).apply()
                } else {
                    prefs.edit().putString(
                        MainActivity.KEY_LAST_SCAN,
                        "Window observed: package=$packageName; windowType=${entry.windowType}; " +
                            "windowId=${entry.windowId}; eventPackage=${event.packageName ?: "unknown"}. " +
                            "No offer-like text exposed."
                    ).apply()
                }
                continue
            }

            val hasPickup = Regex("\\bpick\\s*up\\b|\\bpickup\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)
            val hasDrop = Regex("\\bdrop\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)
            val countdown = ACCEPT_COUNTDOWN.find(text)
            val fareMatch = STANDALONE_RUPEE.find(text)
            val strongOffer = hasPickup && hasDrop && countdown != null && fareMatch != null

            if (!strongOffer) {
                // A lightweight diagnostic helps determine whether Android exposes the popup tree.
                if (lower.contains("accept") || lower.contains("pickup") || lower.contains("drop")) {
                    prefs.edit().putString(
                        MainActivity.KEY_LAST_SCAN,
                        "Porter window seen, but offer signature incomplete. package=$packageName; pickup=$hasPickup; drop=$hasDrop; countdown=${countdown != null}; fare=${fareMatch != null}; windowType=${entry.windowType}"
                    ).apply()
                }
                continue
            }

            val amount = fareMatch!!.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")?.toDoubleOrNull() ?: 100.0
            val eligible = amount >= minimum
            val fingerprint = listOf(
                packageName,
                fareMatch.value,
                extractRoutePart(text, "pickup"),
                extractRoutePart(text, "drop")
            ).joinToString("|")
            val now = System.currentTimeMillis()

            if (fingerprint != lastFingerprint || now - lastSavedAt >= 45000L) {
                lastFingerprint = fingerprint
                lastSavedAt = now
                prefs.edit()
                    .putString(MainActivity.KEY_LAST_TITLE, "FLOATING PORTER OFFER")
                    .putString(MainActivity.KEY_LAST_TEXT, text.take(1200))
                    .putString(MainActivity.KEY_LAST_STATUS, if (eligible) "QUALIFYING OFFER • ₹${format(amount)} meets your ₹${format(minimum)} minimum" else "BELOW MINIMUM • ₹${format(amount)} is below your ₹${format(minimum)} minimum")
                    .putString(MainActivity.KEY_LAST_PACKAGE, packageName)
                    .putString(MainActivity.KEY_LAST_ACTION, "Offer detected • countdown ${countdown!!.groupValues[1]}s • not accepted")
                    .putString(MainActivity.KEY_LAST_SCAN, "Strong floating-offer signature matched in Porter window $packageName (type ${entry.windowType}).")
                    .putLong(MainActivity.KEY_LAST_TIME, now)
                    .apply()
            }

            if (eligible && prefs.getBoolean(MainActivity.KEY_AUTO_ACCEPT, false)) {
                val alreadyAttempted = prefs.getString(MainActivity.KEY_LAST_CLICK_FINGERPRINT, "") == fingerprint &&
                    now - prefs.getLong(MainActivity.KEY_LAST_CLICK_TIME, 0L) < 45000L
                if (!alreadyAttempted && now - lastClickAt > 1800L) {
                    val acceptNode = findAcceptControl(entry.root)
                    if (acceptNode != null) {
                        val clicked = performAcceptClick(acceptNode)
                        lastClickAt = now
                        prefs.edit()
                            .putString(MainActivity.KEY_LAST_CLICK_FINGERPRINT, fingerprint)
                            .putLong(MainActivity.KEY_LAST_CLICK_TIME, now)
                            .putString(MainActivity.KEY_LAST_ACTION, if (clicked) "Accept click attempted • verify Porter confirmed the booking" else "Accept control found, but Android rejected the click")
                            .apply()
                    } else {
                        prefs.edit().putString(MainActivity.KEY_LAST_ACTION, "Qualifying offer detected, but no clickable Accept control was exposed").apply()
                    }
                }
            }
            return
        }
    }

    private fun findAcceptControl(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        while (queue.isNotEmpty()) {
            val (node, depth) = queue.removeFirst()
            if (depth > 24) continue
            try {
                val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                    .joinToString(" ").trim().lowercase(Locale.ROOT)
                // The actual Porter card displays text such as "Accept in 7s".
                if (label.startsWith("accept") && !label.startsWith("accepted")) {
                    if (node.isClickable) return node
                    val parent = node.parent
                    if (parent != null && parent.isClickable) return parent
                }
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it to depth + 1) }
            } catch (_: Exception) { }
        }
        return null
    }

    private fun performAcceptClick(node: AccessibilityNodeInfo): Boolean {
        return try {
            if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) true
            else {
                val parent = node.parent
                parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
            }
        } catch (_: Exception) { false }
    }

    private fun collectVisibleText(root: AccessibilityNodeInfo): String {
        val chunks = linkedSetOf<String>()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        while (queue.isNotEmpty() && chunks.size < 500) {
            val (node, depth) = queue.removeFirst()
            if (depth > 26) continue
            try {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { chunks.add(it) }
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it to depth + 1) }
            } catch (_: Exception) { }
        }
        return chunks.joinToString("\n")
    }

    private fun extractRoutePart(text: String, label: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val index = lines.indexOfFirst { it.equals(label, true) || it.contains(label, true) }
        return if (index >= 0) lines.drop(index).take(3).joinToString(" ").take(140) else ""
    }

    private fun format(value: Double) = String.format(Locale.US, "%.2f", value)
    override fun onInterrupt() {}

    companion object {
        private val STANDALONE_RUPEE = Regex("₹\\s*([0-9,]+(?:\\.[0-9]{1,2})?)")
        private val ACCEPT_COUNTDOWN = Regex("accept\\s+in\\s+(\\d+)\\s*s", RegexOption.IGNORE_CASE)
    }
}

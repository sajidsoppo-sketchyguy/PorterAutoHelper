package com.example.porterautohelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Diagnostic-only screen reader.
 * Reads visible text only while the active app package identifies as Porter.
 * It never clicks, swipes, or accepts an order.
 */
class PorterAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val eventPackage = event.packageName?.toString().orEmpty().lowercase(Locale.ROOT)
        val root = rootInActiveWindow ?: return
        val activePackage = root.packageName?.toString().orEmpty().lowercase(Locale.ROOT)

        // Only inspect windows belonging to a Porter app. Ignore this helper and all other apps.
        if (!eventPackage.contains("porter") && !activePackage.contains("porter")) return
        if (!activePackage.contains("porter")) return

        val collected = StringBuilder()
        collectVisibleText(root, collected, 0)
        val screenText = collected.toString().trim()
        if (screenText.isBlank()) {
            saveResult("Porter screen detected, but no readable text was exposed by Accessibility.", "")
            return
        }

        val amountMatch = Regex("(?:₹|Rs\\.?\\s*)([0-9,]+(?:\\.\\d{1,2})?)", RegexOption.IGNORE_CASE)
            .find(screenText)
        val amount = amountMatch?.groupValues?.getOrNull(1)
            ?.replace(",", "")?.toDoubleOrNull()

        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")?.toDoubleOrNull() ?: 100.0
        val status = when {
            amount == null -> "Porter screen detected; readable text found, but no ₹ amount was recognised."
            amount >= minimum -> "Porter screen detected: ₹${"%.2f".format(Locale.US, amount)} meets minimum ₹${"%.2f".format(Locale.US, minimum)}. Review and decide in Porter."
            else -> "Porter screen detected: ₹${"%.2f".format(Locale.US, amount)} is below minimum ₹${"%.2f".format(Locale.US, minimum)}."
        }
        saveResult(status, screenText)
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 35 || out.length > 12000) return
        val text = node.text?.toString()?.trim().orEmpty()
        val description = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotBlank()) out.append(text).append('\n')
        if (description.isNotBlank() && description != text) out.append(description).append('\n')
        for (i in 0 until node.childCount) {
            collectVisibleText(node.getChild(i), out, depth + 1)
            if (out.length > 12000) break
        }
    }

    private fun saveResult(status: String, text: String) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
            .putString(MainActivity.KEY_LAST_TITLE, "Porter screen")
            .putString(MainActivity.KEY_LAST_TEXT, text.take(5000))
            .putString(MainActivity.KEY_LAST_STATUS, status)
            .putLong(MainActivity.KEY_LAST_TIME, System.currentTimeMillis())
            .apply()
    }

    override fun onInterrupt() {}
}

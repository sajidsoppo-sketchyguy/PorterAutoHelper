package com.example.porterautohelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    companion object {
        const val PREFS = "porter_helper_prefs"
        const val KEY_MIN_AMOUNT = "minimum_amount"
        const val KEY_LAST_TITLE = "last_title"
        const val KEY_LAST_TEXT = "last_text"
        const val KEY_LAST_STATUS = "last_status"
        const val KEY_LAST_TIME = "last_time"
    }

    private lateinit var minAmount: EditText
    private lateinit var latest: TextView
    private lateinit var prefs: android.content.SharedPreferences

    private val green = Color.rgb(25, 125, 88)
    private val pale = Color.rgb(232, 238, 233)
    private val background = Color.rgb(16, 23, 19)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        window.decorView.systemUiVisibility = 0
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "PORTER AUTO HELPER"
            textSize = 22f
            setTextColor(Color.rgb(25, 183, 122))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(10))
        }
        val intro = TextView(this).apply {
            text = "2-wheeler goods orders • Order detection helper"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(pale)
            setPadding(0, 0, 0, dp(22))
        }
        val amountLabel = TextView(this).apply {
            text = "Minimum order amount (₹)"
            textSize = 16f
            setTextColor(pale)
        }
        minAmount = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(prefs.getString(KEY_MIN_AMOUNT, "100") ?: "100")
            hint = "100"
            textSize = 20f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }

        latest = TextView(this).apply {
            textSize = 15f
            setTextColor(pale)
            setPadding(dp(4), dp(16), dp(4), dp(16))
            text = ""
        }

        val save = makeButton("SAVE MINIMUM AMOUNT") {
            val amount = minAmount.text.toString().trim().toDoubleOrNull()
            if (amount == null || amount < 0) {
                latest.text = "Enter a valid minimum amount."
            } else {
                prefs.edit().putString(KEY_MIN_AMOUNT, amount.toString()).apply()
                latest.text = "Minimum saved: ₹${"%.2f".format(Locale.US, amount)}"
            }
        }
        val permission = makeButton("NOTIFICATION ACCESS") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        val accessibility = makeButton("SCREEN-READING ACCESS") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val refresh = makeButton("REFRESH LATEST RESULT") { refreshLatest() }

        content.addView(title, fullWidth())
        content.addView(intro, fullWidth())
        content.addView(amountLabel, fullWidth())
        content.addView(minAmount, fullWidth())
        content.addView(save, buttonParams())
        content.addView(permission, buttonParams())
        content.addView(accessibility, buttonParams())
        content.addView(refresh, buttonParams())
        content.addView(latest, fullWidth())

        val note = TextView(this).apply {
            text = "Diagnostic version 0.2. Reads notification text from Porter apps and visible screen text when Android Accessibility exposes it. It never taps, slides, or accepts orders. Review every order yourself. Accessibility access can expose screen content."
            textSize = 13f
            setTextColor(pale)
            setPadding(dp(4), dp(8), dp(4), dp(12))
        }
        content.addView(note, fullWidth())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        setContentView(scroll)
        refreshLatest()
    }

    override fun onResume() {
        super.onResume()
        if (::latest.isInitialized) refreshLatest()
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener { action() }
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun fullWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun buttonParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        }

    private fun refreshLatest() {
        val title = prefs.getString(KEY_LAST_TITLE, "").orEmpty()
        val body = prefs.getString(KEY_LAST_TEXT, "").orEmpty()
        val status = prefs.getString(KEY_LAST_STATUS, "No Porter notification or readable Porter screen recorded yet.").orEmpty()
        val time = prefs.getLong(KEY_LAST_TIME, 0L)
        val timeText = if (time > 0) DateFormat.getDateTimeInstance().format(Date(time)) else "Not yet"
        latest.text = buildString {
            append("LATEST DETECTION\n")
            append(status).append("\n\n")
            append("Last detected: ").append(timeText)
            if (title.isNotBlank()) append("\n\n").append(title)
            if (body.isNotBlank()) append("\n").append(body)
        }
    }
}

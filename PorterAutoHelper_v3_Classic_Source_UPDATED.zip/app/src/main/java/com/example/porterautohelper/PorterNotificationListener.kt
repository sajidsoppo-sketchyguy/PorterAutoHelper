package com.example.porterautohelper

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.os.Bundle
import java.util.Locale

class PorterNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Do not treat download, WhatsApp, or other apps as Porter orders.
        if (!sbn.packageName.lowercase(Locale.ROOT).contains("porter")) return

        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.distinct().joinToString("\n")
        if (combined.isBlank()) return

        val amount = Regex("(?:₹|rs\\.?\\s*)([0-9,]+(?:\\.\\d{1,2})?)", RegexOption.IGNORE_CASE)
            .find(combined)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val minimum = prefs.getString(MainActivity.KEY_MIN_AMOUNT, "100")?.toDoubleOrNull() ?: 100.0
        val status = when {
            amount == null -> "Porter notification detected, but no readable amount was found."
            amount >= minimum -> "Porter notification: ₹${"%.2f".format(Locale.US, amount)} meets minimum. Review it in Porter."
            else -> "Porter notification: ₹${"%.2f".format(Locale.US, amount)} is below minimum."
        }
        prefs.edit()
            .putString(MainActivity.KEY_LAST_TITLE, title.ifBlank { "Porter notification" })
            .putString(MainActivity.KEY_LAST_TEXT, combined)
            .putString(MainActivity.KEY_LAST_STATUS, status)
            .putLong(MainActivity.KEY_LAST_TIME, System.currentTimeMillis())
            .apply()
    }
}

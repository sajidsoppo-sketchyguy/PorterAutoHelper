# Porter Auto Helper v0.2 diagnostic source

This source adds a diagnostic AccessibilityService that reads visible text only when the active window belongs to an app whose package name contains `porter`. It records a detected rupee amount and compares it with the user's configured minimum.

The notification listener is restricted to package names containing `porter`, so unrelated download notifications are ignored.

The app does NOT click, swipe, slide, or accept orders. It does not use Porter APIs or bypass app protections. Accessibility text extraction depends on what the Porter app exposes to Android; some overlays may expose no readable nodes, in which case the diagnostic will report that limitation.

Build using the existing GitHub Actions workflow. The ZIP filename expected by the workflow is `PorterAutoHelper_v3_Classic_Source.zip` unless the workflow is updated.
